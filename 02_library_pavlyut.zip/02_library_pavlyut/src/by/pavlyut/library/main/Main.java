package by.pavlyut.library.main;

import by.pavlyut.library.entity.library.Library;
import by.pavlyut.library.factory.fileread.FileRead;

/**
 * Created by Lenigard on 10.10.2016.
 */
public class Main {

    public static void main(String args[]) {
        Library library = new Library();
        FileRead fileReader = new FileRead();
        library = fileReader.readLibrary();
    }
}
