package by.pavlyut.library.factory.fileread;

import by.pavlyut.library.entity.library.Library;
import by.pavlyut.library.entity.literature.Albom;
import by.pavlyut.library.entity.literature.Book;
import by.pavlyut.library.entity.literature.Comix;
import by.pavlyut.library.entity.literature.Magazine;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class FileRead {

    private final static String LIBRARYFILE = "file\\library.txt";

    public Library readLibrary() {
        Library library = new Library();
        try {
            BufferedReader br = new BufferedReader(new FileReader(LIBRARYFILE));
            String sCurrentLine;
            String[] parameters;
            while ((sCurrentLine = br.readLine()) != null) {
                parameters = sCurrentLine.split(" ");
                switch (parameters[0]) {
                    case "Albom":
                        library.addAlbom(new Albom(parameters));
                        break;
                    case "Magazine":
                        library.addMagazine(new Magazine(parameters));
                        break;
                    case "Book":
                        library.addBook(new Book(parameters));
                        break;
                    case "Comix":
                        library.addComix(new Comix(parameters));
                        break;
                    default:
                        break;
                }
            }
            br.close();
        } catch (IOException e) {
            System.out.println("Hi?");
        }

        return library;
    }
}
