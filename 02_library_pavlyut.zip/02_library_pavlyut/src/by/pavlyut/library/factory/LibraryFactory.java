package by.pavlyut.library.factory;

import by.pavlyut.library.entity.library.Library;

/**
 * Created by Lenigard on 10.10.2016.
 */
public class LibraryFactory {

}
