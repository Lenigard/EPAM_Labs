package by.pavlyut.texthandler.composite;

/**
 * Created by Lenigard on 14.11.2016.
 */
public enum NonSeparatableType {
    DELIMITER, WORD, NUMBER;
}
