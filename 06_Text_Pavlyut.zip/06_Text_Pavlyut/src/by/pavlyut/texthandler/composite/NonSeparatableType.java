package by.pavlyut.texthandler.composite;

public enum NonSeparatableType {
    DELIMITER, WORD, NUMBER;
}
