function correctionCheck(line, splited_line){
	var step_count = 0;

	for(word of splited_line) {
		step_count += word.length;
	}
	if(step_count != line.length) {
		step_count = 0;
		return true;
	}
	step_count = 0;
	return false;
}

function validate(){
	var login_regex = /[\w]+/g;
	var name_regex = /[а-яА-Яa-zA-Z\d ]+/g;
	var email_regex = /([A-Z|a-z|0-9](\.|_){0,1})+[A-Z|a-z|0-9]\@([A-Z|a-z|0-9])+((\.){0,1}[A-Z|a-z|0-9]){2}\.[a-z]{2,3}/g;
	var password_regex = /[\w.]+/g;
	var login = document.getElementById('login');
	var name = document.getElementById('name');
	var email = document.getElementById('email');
	var password = document.getElementById('password');
	var password_check = document.getElementById('password_check');
	var age = document.getElementById('age');
	if (login.value.match(login_regex) == null || correctionCheck(login.value, login.value.match(login_regex))) {
		console.log("Ошибка ввода логина.");
		login.className = "wrong_input";
	}
	else{
		login.className = "correct_input";
	}
	if (name.value.match(name_regex) == null || correctionCheck(name.value, name.value.match(name_regex))) {
		console.log("Ошибка ввода имени.");
		name.className = "wrong_input";
	}
	else{
		name.className = "correct_input";
	}
	if (email.value.match(email_regex) == null || correctionCheck(email.value, email.value.match(email_regex))) {
		console.log("Ошибка ввода email.");
		email.className = "wrong_input";
	}
	else{
		email.className = "correct_input";
	}
	if (password.value.match(password_regex) == null || correctionCheck(password.value, password.value.match(password_regex))) {
		console.log("Ошибка ввода пароля.");
		password.className = "wrong_input";
	}
	else{
		if(password.value !== password_check.value) {
			console.log("Ошибка подтверждения пароля.");
			password.className = "wrong_input";
			password_check.className = "wrong_input";
		}
		else{
			password.className = "correct_input";
			password_check.className = "correct_input";
		}
	}
	if (isNaN(age.value) && (parseInt(age.value) < 0 || parseInt(age.value) > 120)) {
		console.log("Ошибка ввода имени.");
	}
}