package by.pavlyut.xmlparser.voucherinfo;

/**
 * Created by Lenigard on 21.11.16.
 */
public enum VoucherStruct {
    COUNTRY("country"),
    NAME("Name"),
    ID("id"),
    DAYS("days"),
    COST("cost"),
    STARS("stars"),
    PLACES_COUNT("places-count"),
    NUTRITION("nutrition"),
    TRANSPORT_TYPE("transport-type"),
    CROSSING_DAYTIME("crossing-daytime"),
    CROSSING_COUNT("crossing-count"),
    DISTANCE_FROM_BEACH("distance-from-beach");


    private String text;

    private VoucherStruct(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
