package by.pavlyut.xmlparser.voucherinfo;

/**
 * Created by Lenigard on 21.11.16.
 */
public enum VoucherType {
    HOTEL("Hotel"), BUNGALOW("Bungalow"), TOURISM("Tourism");

    private String type;

    private VoucherType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
