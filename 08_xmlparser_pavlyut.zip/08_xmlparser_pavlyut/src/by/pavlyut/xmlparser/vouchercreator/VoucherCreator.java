package by.pavlyut.xmlparser.vouchercreator;

import by.pavlyut.xmlparser.entity.BungalowVoucherBuilder;
import by.pavlyut.xmlparser.entity.CommonVoucherBuilder;
import by.pavlyut.xmlparser.entity.HotelVoucherBuilder;
import by.pavlyut.xmlparser.entity.TourismVoucherBuilder;
import by.pavlyut.xmlparser.voucherinfo.VoucherType;

/**
 * Created by Lenigard on 21.11.16.
 */
public class VoucherCreator {
    public static CommonVoucherBuilder getVoucher(VoucherType type){
        CommonVoucherBuilder voucher = null;
        switch(type){
            case HOTEL:
                voucher = new HotelVoucherBuilder();
                break;
            case BUNGALOW:
                voucher = new BungalowVoucherBuilder();
                break;
            case TOURISM:
                voucher = new TourismVoucherBuilder();
                break;
            default:
                break;
        }
        return voucher;
    }
}
