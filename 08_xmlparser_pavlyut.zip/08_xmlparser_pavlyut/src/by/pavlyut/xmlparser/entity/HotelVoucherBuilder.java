package by.pavlyut.xmlparser.entity;

import by.pavlyut.xmlparser.vouchesbuilder.HotelVoucher;

/**
 * Created by Lenigard on 21.11.16.
 */
public class HotelVoucherBuilder extends CommonVoucherBuilder {

    public HotelVoucherBuilder(){
        this.voucher = new HotelVoucher();
    }
    @Override
    public void buildTransportType(String transportType) {

    }

    @Override
    public void buildCrossingDaytime(String crossingDaytime) {

    }

    @Override
    public void buildCrossingCount(int crossingCount) {

    }

    @Override
    public void buildPlacesCount(int placesCount) {
        ((HotelVoucher)voucher).setPlacesCount(placesCount);
    }

    @Override
    public void buildNutrition(String nutrition) {
        ((HotelVoucher)voucher).setNutrition(nutrition);
    }

    @Override
    public void buildStars(int stars) {
        ((HotelVoucher)voucher).setStars(stars);
    }

    @Override
    public void buildDistanceFromBeach(int distanceFromBeach) {

    }

    @Override
    public void buildName(String name) {
        ((HotelVoucher)voucher).setName(name);
    }
}
