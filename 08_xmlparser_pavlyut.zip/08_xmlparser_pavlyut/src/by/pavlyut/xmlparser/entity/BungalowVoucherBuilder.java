package by.pavlyut.xmlparser.entity;


import by.pavlyut.xmlparser.vouchesbuilder.BungalowVoucher;

public class BungalowVoucherBuilder extends CommonVoucherBuilder {

    public BungalowVoucherBuilder() {
        this.voucher = new BungalowVoucher();
    }

    @Override
    public void buildTransportType(String trannsportType) {

    }

    @Override
    public void buildCrossingDaytime(String crossingDaytime) {

    }

    @Override
    public void buildCrossingCount(int crossingCount) {

    }

    @Override
    public void buildPlacesCount(int placesCount) {

    }

    @Override
    public void buildNutrition(String nutrition) {

    }

    @Override
    public void buildStars(int stars) {

    }

    @Override
    public void buildDistanceFromBeach(int distanceFromBeach) {
        ((BungalowVoucher)voucher).setDistanceFromBeach(distanceFromBeach);
    }

    @Override
    public void buildName(String str) {

    }
}
