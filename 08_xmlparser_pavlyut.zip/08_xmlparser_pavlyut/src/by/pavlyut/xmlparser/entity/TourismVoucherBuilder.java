package by.pavlyut.xmlparser.entity;

import by.pavlyut.xmlparser.vouchesbuilder.TourismVoucher;

/**
 * Created by Lenigard on 21.11.16.
 */
public class TourismVoucherBuilder extends CommonVoucherBuilder{

    public TourismVoucherBuilder(){
        this.voucher = new TourismVoucher();
    }

    @Override
    public void buildTransportType(String transportType) {
        ((TourismVoucher)voucher).setTransportType(transportType);
    }

    @Override
    public void buildCrossingDaytime(String crossingDaytime) {
        ((TourismVoucher)voucher).setCrossingDaytime(crossingDaytime);
    }

    @Override
    public void buildCrossingCount(int crossingCount) {
        ((TourismVoucher)voucher).setCrossingCount(crossingCount);
    }

    @Override
    public void buildPlacesCount(int placesCount) {

    }

    @Override
    public void buildNutrition(String nutrition) {

    }

    @Override
    public void buildStars(int stars) {

    }

    @Override
    public void buildDistanceFromBeach(int distanceFromBeach) {

    }

    @Override
    public void buildName(String str) {

    }
}
