package by.pavlyut.xmlparser.entity;

import by.pavlyut.xmlparser.vouchesbuilder.CommonVoucher;

import java.util.List;

/**
 * Created by Lenigard on 21.11.16.
 */
public abstract class CommonVoucherBuilder {

    protected CommonVoucher voucher;

    public abstract void buildTransportType(String transportType);
    public abstract void buildCrossingDaytime(String crossingDaytime);
    public abstract void buildCrossingCount(int crossingCount);
    public abstract void buildPlacesCount(int placesCount);
    public abstract void buildNutrition(String nutrition);
    public abstract void buildStars(int stars);
    public abstract void buildDistanceFromBeach(int distanceFromBeach);
    public abstract void buildName(String str);

    public void buildCountry(String country){
        voucher.setCountry(country);
    }

    public void buildDays(int days) {
        voucher.setDays(days);
    }

    public void buildId(String id) {
        voucher.setId(id);
    }

    public void buildCost(int cost) {
        voucher.setCost(cost);
    }

    public CommonVoucher getVoucher() {
        return voucher;
    }



}
