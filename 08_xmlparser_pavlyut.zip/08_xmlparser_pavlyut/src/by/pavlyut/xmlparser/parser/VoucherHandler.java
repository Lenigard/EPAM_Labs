package by.pavlyut.xmlparser.parser;

import by.pavlyut.xmlparser.entity.CommonVoucherBuilder;
import by.pavlyut.xmlparser.vouchercreator.VoucherCreator;
import by.pavlyut.xmlparser.voucherinfo.VoucherStruct;
import by.pavlyut.xmlparser.voucherinfo.VoucherType;
import by.pavlyut.xmlparser.vouchesbuilder.CommonVoucher;
import jdk.internal.org.xml.sax.Attributes;
import jdk.internal.org.xml.sax.helpers.DefaultHandler;

import java.util.HashSet;
import java.util.Set;

public class VoucherHandler extends DefaultHandler {

    private CommonVoucherBuilder voucher;
    private VoucherStruct voucherStructureElement;
    private Set<CommonVoucher> vouchers;

    public VoucherHandler() {
        vouchers = new HashSet<>();
    }

    @Override
    public void startDocument() {
        System.out.println("Parsing started");
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attrs) {
        VoucherType voucherType = voucherElement(localName);
        if (voucherType != null) {
            voucher = VoucherCreator.getVoucher(voucherType);
        } else {
            for (VoucherStruct structure : VoucherStruct.values()) {
                if (structure.getText().equalsIgnoreCase(localName)) {
                    voucherStructureElement = structure;
                    break;
                }
            }
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) {
        String str = new String(ch, start, length).trim();
        if(voucherStructureElement != null){
            switch (voucherStructureElement){
                case COUNTRY:
                    voucher.buildCountry(str);
                    break;
                case COST:
                    voucher.buildCost(Integer.parseInt(str));
                    break;
                case DAYS:
                    voucher.buildDays(Integer.parseInt(str));
                    break;
                case ID:
                    voucher.buildCrossingCount(Integer.parseInt(str));
                    break;
                case NAME:
                    voucher.buildName(str);
                    break;
                case STARS:
                    voucher.buildStars(Integer.parseInt(str));
                    break;
                case TRANSPORT_TYPE:
                    voucher.buildTransportType(str);
                    break;
                case CROSSING_COUNT:
                    voucher.buildCrossingCount(Integer.parseInt(str));
                    break;
                case CROSSING_DAYTIME:
                    voucher.buildCrossingDaytime(str);
                    break;
                case PLACES_COUNT:
                    voucher.buildPlacesCount(Integer.parseInt(str));
                    break;
                case NUTRITION:
                    voucher.buildNutrition(str);
                    break;
                case DISTANCE_FROM_BEACH:
                    voucher.buildDistanceFromBeach(Integer.parseInt(str));
                    break;
            }
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) {
        for (VoucherType type : VoucherType.values()) {
            if (type.getType().equalsIgnoreCase(localName)) {
                vouchers.add(voucher.getVoucher());
                break;
            }
        }
    }

    @Override
    public void endDocument() {
        System.out.println("\nParsing ended");
    }

    private VoucherType voucherElement(String localName) {
        for (VoucherType type : VoucherType.values()) {
            if (type.getType().equalsIgnoreCase(localName)) {
                return type;
            }
        }
        return null;
    }

    public Set<CommonVoucher> getCards() {
        return vouchers;
    }
}
