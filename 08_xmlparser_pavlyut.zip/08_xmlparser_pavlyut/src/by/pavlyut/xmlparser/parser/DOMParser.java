package by.pavlyut.xmlparser.parser;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import by.pavlyut.xmlparser.vouchesbuilder.CommonVoucher;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMParser {
    private Set<CommonVoucher> vouchers;
    private DocumentBuilder docBuilder;
    private final static Logger LOG = LogManager.getLogger(SAXBuilder.class.getName());

    public DOMParser() {
        this.vouchers = new HashSet<CommonVoucher>();
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        try {
            docBuilder = factory.newDocumentBuilder();
        } catch (ParserConfigurationException e) {
            LOG.error(e);
        }
    }

    public void buildSetVoucher(String fileName) {
        Document doc = null;
        try {
            doc = docBuilder.parse(fileName);
            Element rootElement = doc.getDocumentElement();
            NodeList nodeCards = rootElement.getChildNodes();
            for (int i = 0; i < nodeCards.getLength(); i++) {
                Node node = nodeCards.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    vouchers.add(buildVoucher(element));
                }
            }
        } catch (IOException e) {
            System.err.println("File error or I/O error: " + e);
        } catch (SAXException e) {
            System.err.println("Parsing failure: " + e);
        }
    }

    private CommonVoucher buildVoucher(Element studentElement) {
        CommonVoucher voucher = new CommonVoucher();
        /*voucher.setFaculty(studentElement.getAttribute("faculty"));
        voucher.setName(getElementTextContent(studentElement, "name"));
        Integer tel = Integer.parseInt(getElementTextContent(studentElement, "telephone"));
        voucher.setTelephone(tel);
        Student.Address address = voucher.getAddress();
        Element adressElement = (Element) studentElement.getElementsByTagName("address").item(0);
        address.setCountry(getElementTextContent(adressElement, "country"));
        address.setCity(getElementTextContent(adressElement, "city"));
        address.setStreet(getElementTextContent(adressElement, "street"));
        voucher.setLogin(studentElement.getAttribute("login"));*/
        return voucher;
    }

    private static String getElementTextContent(Element element, String elementName) {
        NodeList nList = element.getElementsByTagName(elementName);
        Node node = nList.item(0);
        String text = node.getTextContent();
        return text;
    }

    public Set<CommonVoucher> getStudents() {
        return vouchers;
    }
}
