package by.pavlyut.xmlparser.parser;

import by.pavlyut.xmlparser.vouchesbuilder.CommonVoucher;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public class SAXBuilder {

    private final static Logger LOG = LogManager.getLogger(SAXBuilder.class.getName());
    private VoucherHandler vouncherHandler;
    private Set<CommonVoucher> vouchers;
    private XMLReader reader;

    public SAXBuilder() {
        vouchers = new HashSet<>();
        vouncherHandler = new VoucherHandler();
        try {
            reader = XMLReaderFactory.createXMLReader();
            reader.setContentHandler((ContentHandler) vouncherHandler);
        } catch (SAXException exception) {
            LOG.fatal(exception);
        }
    }

    public void buildSetVouchers(String pathFile) {
        try {
            reader.parse(pathFile);
        } catch (IOException exception) {
            LOG.fatal(exception);
            throw new RuntimeException(exception);
        } catch (SAXException exception) {
            LOG.error(exception);
        }
        vouchers = vouncherHandler.getCards();
    }

    public Set<CommonVoucher> getVouchers() {
        return vouchers;
    }
}
