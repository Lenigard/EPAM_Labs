package by.pavlyut.xmlparser.vouchesbuilder;

/**
 * Created by Lenigard on 21.11.16.
 */
public class HotelVoucher extends CommonVoucher {

    private int stars;
    private int placesCount;
    private String nutrition;
    private String name;


    public HotelVoucher() {
    }

    public HotelVoucher(String country, String id, int days, int cost, int stars, int placesCount, String nutrition) {
        super(country, id, days, cost);
        this.stars = stars;
        this.placesCount = placesCount;
        this.nutrition = nutrition;
    }

    public int getStars() {
        return stars;
    }

    public void setStars(int stars) {
        this.stars = stars;
    }

    public int getPlacesCount() {
        return placesCount;
    }

    public void setPlacesCount(int placesCount) {
        this.placesCount = placesCount;
    }

    public String getNutrition() {
        return nutrition;
    }

    public void setNutrition(String nutrition) {
        this.nutrition = nutrition;
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        HotelVoucher that = (HotelVoucher) o;

        if (stars != that.stars) {
            return false;
        }
        if (placesCount != that.placesCount) {
            return false;
        }
        return nutrition != null ? nutrition.equals(that.nutrition) : that.nutrition == null;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + stars;
        result = 31 * result + placesCount;
        result = 31 * result + (nutrition != null ? nutrition.hashCode() : 0);
        result = 31 * result + (name != null ? name.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return super.toString() + ", stars=" + stars + ", placesCount=" + placesCount + ", nutrition='" + nutrition;
    }
}
