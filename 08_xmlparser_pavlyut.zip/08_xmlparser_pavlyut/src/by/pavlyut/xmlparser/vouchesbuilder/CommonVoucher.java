package by.pavlyut.xmlparser.vouchesbuilder;

/**
 * Created by Lenigard on 21.11.16.
 */
public class CommonVoucher {
    private String country;
    private String id;
    private int days;
    private int cost;

    public CommonVoucher(){
    }

    public CommonVoucher(String country, String id, int days, int cost) {
        this.country = country;
        this.id = id;
        this.days = days;
        this.cost = cost;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        CommonVoucher that = (CommonVoucher) o;
        if (days != that.days) {
            return false;
        }
        if (cost != that.cost) {
            return false;
        }
        if (!country.equals(that.country)) {
            return false;
        }
        return id.equals(that.id);

    }

    @Override
    public int hashCode() {
        int result = country.hashCode();
        result = 31 * result + id.hashCode();
        result = 31 * result + days;
        result = 31 * result + cost;
        return result;
    }

    @Override
    public String toString() {
        return country + '\'' + ", id='" + id + '\'' + ", days=" + days + ", cost=" + cost + '}';
    }
}
