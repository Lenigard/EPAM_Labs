package by.pavlyut.xmlparser.vouchesbuilder;

/**
 * Created by Lenigard on 21.11.16.
 */
public class TourismVoucher extends CommonVoucher {
    private String transportType;
    private String crossingDaytime;
    private int crossingCount;

    public TourismVoucher(){
    }

    public TourismVoucher(String country, String id, int days, int cost, String transportType, String crossingDaytime, int crossingCount) {
        super(country, id, days, cost);
        this.transportType = transportType;
        this.crossingDaytime = crossingDaytime;
        this.crossingCount = crossingCount;
    }

    public String getTransportType() {
        return transportType;
    }

    public void setTransportType(String transportType) {
        this.transportType = transportType;
    }

    public String getCrossingDaytime() {
        return crossingDaytime;
    }

    public void setCrossingDaytime(String crossingDaytime) {
        this.crossingDaytime = crossingDaytime;
    }

    public int getCrossingCount() {
        return crossingCount;
    }

    public void setCrossingCount(int crossingCount) {
        this.crossingCount = crossingCount;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }

        TourismVoucher that = (TourismVoucher) o;

        if (crossingCount != that.crossingCount) {
            return false;
        }
        if (transportType != null ? !transportType.equals(that.transportType) : that.transportType != null) {
            return false;
        }
        return crossingDaytime != null ? crossingDaytime.equals(that.crossingDaytime) : that.crossingDaytime == null;

    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + (transportType != null ? transportType.hashCode() : 0);
        result = 31 * result + (crossingDaytime != null ? crossingDaytime.hashCode() : 0);
        result = 31 * result + crossingCount;
        return result;
    }

    @Override
    public String toString() {
        return super.toString() + ", transportType='" + transportType + '\'' + ", crossingDaytime='" + crossingDaytime + '\'' + ", crossingCount=" + crossingCount;
    }
}
