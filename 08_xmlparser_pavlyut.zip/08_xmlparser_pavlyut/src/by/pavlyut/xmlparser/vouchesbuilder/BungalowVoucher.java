package by.pavlyut.xmlparser.vouchesbuilder;

/**
 * Created by Lenigard on 21.11.16.
 */
public class BungalowVoucher extends CommonVoucher {
    private int distanceFromBeach;

    public BungalowVoucher() {
    }

    public BungalowVoucher(String country, String id, int days, int cost, int distanceFromBeach) {
        super(country, id, days, cost);
        this.distanceFromBeach = distanceFromBeach;
    }

    public int getDistanceFromBeach() {
        return distanceFromBeach;
    }

    public void setDistanceFromBeach(int distanceFromBeach) {
        this.distanceFromBeach = distanceFromBeach;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        if (!super.equals(o)) {
            return false;
        }
        BungalowVoucher that = (BungalowVoucher) o;
        return distanceFromBeach == that.distanceFromBeach;
    }

    @Override
    public int hashCode() {
        int result = super.hashCode();
        result = 31 * result + distanceFromBeach;
        return result;
    }

    @Override
    public String toString() {
        return super.toString() + "distanceFromBeach=" + distanceFromBeach;
    }
}
